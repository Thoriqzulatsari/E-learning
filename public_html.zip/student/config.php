<?php
// config.php
define('DB_DSN', 'mysql:host=localhost;dbname=your_database;charset=utf8mb4');
define('DB_USER', 'your_db_user');
define('DB_PASSWORD', 'your_secure_password');