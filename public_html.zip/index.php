<?php
// Simple redirect to login page
header('Location: auth/login.php');
exit();