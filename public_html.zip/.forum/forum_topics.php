<?php
// forum/forum_topics.php
require_once '../includes/header.php';

// Initialize database connection
require_once '../includes/db_connection.php';

// Get forum ID from URL
$forum_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Check for stored messages
if (isset($_SESSION['message'])) {
    echo '<div class="container mt-3">';
    echo '<div class="alert alert-' . ($_SESSION['message_type'] === 'error' ? 'danger' : $_SESSION['message_type']) . ' alert-dismissible fade show">';
    echo htmlspecialchars($_SESSION['message']);
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
    echo '</div>';
    echo '</div>';
    
    // Clear the message after displaying
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}

// In a real application, you would fetch the forum details
// $stmt = $conn->prepare("SELECT * FROM forums WHERE id = ?");
// $stmt->execute([$forum_id]);
// $forum = $stmt->fetch(PDO::FETCH_ASSOC);

// Get forum details from our sample data
$forums = [
    1 => [
        'id' => 1,
        'title' => 'Introduction to Web Development',
        'description' => 'Discuss the basics of web development and share your learning journey.'
    ],
    2 => [
        'id' => 2,
        'title' => 'Advanced JavaScript Techniques',
        'description' => 'Share and learn advanced JavaScript concepts and best practices.'
    ],
    3 => [
        'id' => 3,
        'title' => 'UI/UX Design Tips',
        'description' => 'Discuss user interface and user experience design principles and techniques.'
    ]
];

$forum = isset($forums[$forum_id]) ? $forums[$forum_id] : null;

if (!$forum) {
    $_SESSION['message'] = "Forum not found.";
    $_SESSION['message_type'] = "error";
    header("Location: index.php");
    exit;
}

// In a real application, you would fetch topics for this forum
// $stmt = $conn->prepare("SELECT t.*, u.username as author, 
//     (SELECT COUNT(*) FROM replies WHERE topic_id = t.id) as replies_count,
//     (SELECT MAX(created_at) FROM replies WHERE topic_id = t.id) as last_reply
//     FROM topics t JOIN users u ON t.user_id = u.id 
//     WHERE t.forum_id = ? ORDER BY t.created_at DESC");
// $stmt->execute([$forum_id]);
// $topics = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get topics from session if available
$topics = [];
if (isset($_SESSION['topics'])) {
    foreach ($_SESSION['topics'] as $topic) {
        if ($topic['forum_id'] == $forum_id) {
            // Count replies for this topic
            $replies_count = 0;
            $last_reply = null;
            
            if (isset($_SESSION['replies'])) {
                foreach ($_SESSION['replies'] as $reply) {
                    if ($reply['topic_id'] == $topic['id']) {
                        $replies_count++;
                        if (!$last_reply || strtotime($reply['created_at']) > strtotime($last_reply)) {
                            $last_reply = $reply['created_at'];
                        }
                    }
                }
            }
            
            $topics[] = [
                'id' => $topic['id'],
                'title' => $topic['title'],
                'author' => $topic['author'],
                'created_at' => $topic['created_at'],
                'replies_count' => $replies_count,
                'last_reply' => $last_reply
            ];
        }
    }
}

// If no topics in session, use sample data
if (empty($topics)) {
    // Sample topics for demonstration
    $sample_topics = [
        [
            'id' => 1,
            'title' => 'Getting started with HTML and CSS',
            'author' => 'WebNewbie',
            'created_at' => '2025-02-01 10:30:00',
            'replies_count' => 5,
            'last_reply' => '2025-02-03 15:45:00'
        ],
        [
            'id' => 2,
            'title' => 'How to use Flexbox effectively?',
            'author' => 'CSSMaster',
            'created_at' => '2025-02-05 08:15:00',
            'replies_count' => 8,
            'last_reply' => '2025-02-06 19:20:00'
        ],
        [
            'id' => 3,
            'title' => 'JavaScript basics for beginners',
            'author' => 'JSLearner',
            'created_at' => '2025-02-10 14:20:00',
            'replies_count' => 3,
            'last_reply' => '2025-02-12 09:10:00'
        ]
    ];
    
    // Only add sample topics for the current forum
    if ($forum_id == 1) {
        $topics = $sample_topics;
    } else if ($forum_id == 2) {
        $topics = [
            [
                'id' => 4,
                'title' => 'Understanding Promises in JavaScript',
                'author' => 'PromiseMaster',
                'created_at' => '2025-02-03 11:25:00',
                'replies_count' => 12,
                'last_reply' => '2025-02-06 18:30:00'
            ],
            [
                'id' => 5,
                'title' => 'Working with Async/Await',
                'author' => 'JSPro',
                'created_at' => '2025-02-08 09:45:00',
                'replies_count' => 6,
                'last_reply' => '2025-02-09 14:15:00'
            ]
        ];
    } else if ($forum_id == 3) {
        $topics = [
            [
                'id' => 6,
                'title' => 'Best practices for intuitive navigation',
                'author' => 'UXDesigner',
                'created_at' => '2025-02-04 13:40:00',
                'replies_count' => 9,
                'last_reply' => '2025-02-07 10:20:00'
            ],
            [
                'id' => 7,
                'title' => 'Color theory basics for UI design',
                'author' => 'ColorExpert',
                'created_at' => '2025-02-09 15:50:00',
                'replies_count' => 4,
                'last_reply' => '2025-02-11 16:05:00'
            ]
        ];
    }
}
?>

<div class="container my-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Forums</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($forum['title']); ?></li>
        </ol>
    </nav>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1><?php echo htmlspecialchars($forum['title']); ?></h1>
            <p><?php echo htmlspecialchars($forum['description']); ?></p>
        </div>
        <div>
            <a href="create.php?forum_id=<?php echo $forum_id; ?>" class="btn btn-primary">Create New Topic</a>
        </div>
    </div>
    
    <?php if (empty($topics)): ?>
        <div class="alert alert-info">No topics found in this forum. Be the first to create a topic!</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Topic</th>
                        <th>Author</th>
                        <th>Replies</th>
                        <th>Created</th>
                        <th>Last Reply</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topics as $topic): ?>
                        <tr>
                            <td>
                                <a href="topic.php?id=<?php echo $topic['id']; ?>">
                                    <?php echo htmlspecialchars($topic['title']); ?>
                                </a>
                            </td>
                            <td><?php echo htmlspecialchars($topic['author']); ?></td>
                            <td><?php echo $topic['replies_count']; ?></td>
                            <td><?php echo date('M j, Y', strtotime($topic['created_at'])); ?></td>
                            <td>
                                <?php if ($topic['last_reply']): ?>
                                    <?php echo date('M j, Y', strtotime($topic['last_reply'])); ?>
                                <?php else: ?>
                                    No replies yet
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>