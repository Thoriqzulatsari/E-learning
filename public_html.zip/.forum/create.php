<?php
// forum/create.php
require_once '../includes/header.php';
require_once '../includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "You must be logged in to create a topic.";
    $_SESSION['message_type'] = "error";
    header("Location: ../login.php");
    exit;
}

// Get forum categories
$categories = getForumCategories();

// Get courses for selection (if user is enrolled or instructor)
$courses = [];
$user_id = $_SESSION['user_id'];

// In a real app, fetch courses the user is enrolled in or teaches
if (isset($_SESSION['role']) && $_SESSION['role'] == 'instructor') {
    // For instructors, fetch courses they teach
    $stmt = $conn->prepare("SELECT course_id, title FROM courses WHERE instructor_id = ?");
    $stmt->execute([$user_id]);
    $courses = $stmt->fetchAll();
} else {
    // For students, fetch courses they're enrolled in
    $stmt = $conn->prepare("
        SELECT c.course_id, c.title 
        FROM courses c 
        JOIN enrollments e ON c.course_id = e.course_id 
        WHERE e.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $courses = $stmt->fetchAll();
}

// Get pre-selected forum_id from query parameter
$preselected_forum_id = isset($_GET['forum_id']) ? intval($_GET['forum_id']) : 0;
$preselected_category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : 0;

// Check for stored messages
if (isset($_SESSION['message'])) {
    echo '<div class="container mt-3">';
    echo '<div class="alert alert-' . ($_SESSION['message_type'] === 'error' ? 'danger' : $_SESSION['message_type']) . ' alert-dismissible fade show">';
    echo htmlspecialchars($_SESSION['message']);
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
    echo '</div>';
    echo '</div>';
    
    // Clear the message after displaying
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}

// Check if there are form errors to display
$form_errors = [];
if (isset($_SESSION['form_errors'])) {
    $form_errors = $_SESSION['form_errors'];
    unset($_SESSION['form_errors']);
}

// Get any stored form data
$form_data = [];
if (isset($_SESSION['form_data'])) {
    $form_data = $_SESSION['form_data'];
    unset($_SESSION['form_data']);
}
?>

<div class="container my-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Forums</a></li>
            <li class="breadcrumb-item active" aria-current="page">Create New Topic</li>
        </ol>
    </nav>
    
    <h1>Create New Topic</h1>
    
    <?php if (!empty($form_errors)): ?>
    <div class="alert alert-danger">
        <h4>Please correct the following errors:</h4>
        <ul>
            <?php foreach ($form_errors as $error): ?>
            <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <form action="process_topic.php" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="forum_type" class="form-label">Post in</label>
            <select class="form-select" id="forum_type" onchange="toggleForumType(this.value)">
                <option value="course" <?php echo ($preselected_forum_id > 0) ? 'selected' : ''; ?>>Course Forum</option>
                <option value="category" <?php echo ($preselected_category_id > 0) ? 'selected' : ''; ?>>General Category</option>
            </select>
        </div>
        
        <div id="course_selection" class="mb-3 <?php echo ($preselected_category_id > 0) ? 'd-none' : ''; ?>">
            <label for="forum_id" class="form-label">Select Course</label>
            <select class="form-select" id="forum_id" name="forum_id">
                <option value="">Choose a course...</option>
                <?php foreach ($courses as $course): ?>
                <option value="<?php echo $course['course_id']; ?>" <?php echo ((isset($form_data['forum_id']) && $form_data['forum_id'] == $course['course_id']) || $preselected_forum_id == $course['course_id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($course['title']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div id="category_selection" class="mb-3 <?php echo ($preselected_category_id == 0 && $preselected_forum_id == 0) ? 'd-none' : ($preselected_category_id > 0 ? '' : 'd-none'); ?>">
            <label for="category_id" class="form-label">Select Category</label>
            <select class="form-select" id="category_id" name="category_id">
                <option value="">Choose a category...</option>
                <?php foreach ($categories as $category): ?>
                <option value="<?php echo $category['category_id']; ?>" <?php echo ((isset($form_data['category_id']) && $form_data['category_id'] == $category['category_id']) || $preselected_category_id == $category['category_id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($category['category_name']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="mb-3">
            <label for="title" class="form-label">Topic Title</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo isset($form_data['title']) ? htmlspecialchars($form_data['title']) : ''; ?>" required>
        </div>
        
        <div class="mb-3">
            <label for="message" class="form-label">Message</label>
            <textarea class="form-control" id="message" name="message" rows="6" required><?php echo isset($form_data['message']) ? htmlspecialchars($form_data['message']) : ''; ?></textarea>
        </div>
        
        <div class="mb-3">
            <label for="attachments" class="form-label">Attachments (Optional)</label>
            <input type="file" class="form-control" id="attachments" name="attachments[]" multiple>
            <div class="form-text">You can upload images, documents or other files (Max 5MB each)</div>
        </div>
        
        <button type="submit" class="btn btn-primary">Create Topic</button>
        <a href="index.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<script>
function toggleForumType(type) {
    if (type === 'course') {
        document.getElementById('course_selection').classList.remove('d-none');
        document.getElementById('category_selection').classList.add('d-none');
        document.getElementById('forum_id').setAttribute('required', 'required');
        document.getElementById('category_id').removeAttribute('required');
    } else {
        document.getElementById('course_selection').classList.add('d-none');
        document.getElementById('category_selection').classList.remove('d-none');
        document.getElementById('forum_id').removeAttribute('required');
        document.getElementById('category_id').setAttribute('required', 'required');
    }
}
</script>

<?php require_once '../includes/footer.php'; ?>