<?php
// forum/reaction.php
require_once '../includes/header.php';
require_once '../includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "You must be logged in to perform this action.";
    $_SESSION['message_type'] = "error";
    header("Location: ../login.php");
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $topic_id = isset($_POST['topic_id']) ? intval($_POST['topic_id']) : null;
    $reply_id = isset($_POST['reply_id']) ? intval($_POST['reply_id']) : null;
    $type = isset($_POST['type']) ? trim($_POST['type']) : 'like';
    $redirect = isset($_POST['redirect']) ? $_POST['redirect'] : 'index.php';
    
    // Validate reaction type
    $valid_types = ['like', 'helpful', 'insightful'];
    if (!in_array($type, $valid_types)) {
        $type = 'like';
    }
    
    // Basic validation
    $errors = [];
    if (empty($topic_id) && empty($reply_id)) {
        $errors[] = "Invalid content reference";
    }
    
    // If there are no errors, toggle the reaction
    if (empty($errors)) {
        try {
            global $conn;
            
            // Check if reaction already exists
            $stmt = $conn->prepare("
                SELECT reaction_id
                FROM forum_reactions
                WHERE user_id = ?
                AND (topic_id = ? OR reply_id = ?)
                AND reaction_type = ?
            ");
            
            $stmt->execute([$user_id, $topic_id, $reply_id, $type]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                // Remove existing reaction
                $stmt = $conn->prepare("
                    DELETE FROM forum_reactions
                    WHERE reaction_id = ?
                ");
                
                $stmt->execute([$existing['reaction_id']]);
                $message = "Reaction removed.";
            } else {
                // Add new reaction
                $stmt = $conn->prepare("
                    INSERT INTO forum_reactions 
                        (user_id, topic_id, reply_id, reaction_type, created_at)
                    VALUES 
                        (?, ?, ?, ?, NOW())
                ");
                
                $stmt->execute([$user_id, $topic_id, $reply_id, $type]);
                $message = "Reaction added.";
            }
            
            // Redirect back to the page
            header("Location: $redirect");
            exit;
        } catch (Exception $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
    
    // If we got here, there were errors
    if (!empty($errors)) {
        $_SESSION['message'] = implode(' ', $errors);
        $_SESSION['message_type'] = "error";
        header("Location: $redirect");
        exit;
    }
} else {
    // If accessed directly without form submission, redirect to forums
    header("Location: index.php");
    exit;
}
?>