<?php
// forum/process_topic.php
require_once '../includes/header.php';
require_once '../includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "You must be logged in to create a topic.";
    $_SESSION['message_type'] = "error";
    header("Location: ../login.php");
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    $forum_id = isset($_POST['forum_id']) ? intval($_POST['forum_id']) : 0;
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : null;
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $message = isset($_POST['message']) ? trim($_POST['message']) : '';
    $user_id = $_SESSION['user_id'];
    
    // Basic validation
    $errors = [];
    if (empty($forum_id) && empty($category_id)) {
        $errors[] = "Please select a forum or category";
    }
    if (empty($title)) {
        $errors[] = "Title is required";
    }
    if (empty($message)) {
        $errors[] = "Message is required";
    }
    
    // Process file uploads if any
    $attachments = [];
    if (!empty($_FILES['attachments']['name'][0])) {
        $upload_dir = '../uploads/forum/';
        
        // Create directory if it doesn't exist
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        // Define allowed file types
        $allowed_types = [
            'image/jpeg', 'image/png', 'image/gif', 
            'application/pdf', 'application/msword', 
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'text/plain'
        ];
        
        foreach ($_FILES['attachments']['name'] as $key => $name) {
            if ($_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK) {
                $tmp_name = $_FILES['attachments']['tmp_name'][$key];
                $file_type = $_FILES['attachments']['type'][$key];
                
                // Sanitize filename
                $name = preg_replace('/[^a-zA-Z0-9._-]/', '', basename($name));
                
                // Create unique filename
                $filename = uniqid('topic_') . '_' . $name;
                $destination = $upload_dir . $filename;
                
                // Validate file type
                if (!in_array($file_type, $allowed_types)) {
                    $errors[] = "File type not allowed for: $name";
                    continue;
                }
                
                // Check file size (5MB max)
                if ($_FILES['attachments']['size'][$key] > 5242880) {
                    $errors[] = "File $name exceeds maximum size (5MB)";
                    continue;
                }
                
                // Move the uploaded file
                if (move_uploaded_file($tmp_name, $destination)) {
                    $attachments[] = [
                        'filename' => $filename,
                        'original_filename' => $_FILES['attachments']['name'][$key],
                        'filesize' => $_FILES['attachments']['size'][$key],
                        'file_type' => $file_type
                    ];
                } else {
                    $errors[] = "Failed to upload file: $name";
                }
            } else if ($_FILES['attachments']['error'][$key] !== UPLOAD_ERR_NO_FILE) {
                // Map error codes to messages
                $upload_errors = [
                    UPLOAD_ERR_INI_SIZE => "File exceeds the upload_max_filesize directive",
                    UPLOAD_ERR_FORM_SIZE => "File exceeds the MAX_FILE_SIZE directive from the form",
                    UPLOAD_ERR_PARTIAL => "File was only partially uploaded",
                    UPLOAD_ERR_NO_TMP_DIR => "Missing a temporary folder",
                    UPLOAD_ERR_CANT_WRITE => "Failed to write file to disk",
                    UPLOAD_ERR_EXTENSION => "A PHP extension stopped the file upload"
                ];
                
                $error_code = $_FILES['attachments']['error'][$key];
                $error_message = isset($upload_errors[$error_code]) ? $upload_errors[$error_code] : "Unknown upload error";
                $errors[] = "Error uploading $name: $error_message";
            }
        }
    }
    
    // If there are no errors, save the topic
    if (empty($errors)) {
        try {
            global $conn;
            $conn->beginTransaction();
            
            // Insert the topic
            $stmt = $conn->prepare("
                INSERT INTO forum_topics 
                    (course_id, category_id, user_id, title, content, created_at) 
                VALUES 
                    (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$forum_id, $category_id, $user_id, $title, $message]);
            $topic_id = $conn->lastInsertId();
            
            // Insert attachments if any
            if (!empty($attachments)) {
                $stmt = $conn->prepare("
                    INSERT INTO forum_attachments 
                        (topic_id, user_id, filename, original_filename, filesize, file_type, uploaded_at) 
                    VALUES 
                        (?, ?, ?, ?, ?, ?, NOW())
                ");
                
                foreach ($attachments as $file) {
                    $stmt->execute([
                        $topic_id, 
                        $user_id, 
                        $file['filename'], 
                        $file['original_filename'], 
                        $file['filesize'], 
                        $file['file_type']
                    ]);
                }
            }
            
            $conn->commit();
            
            // Redirect to the topic page with a success message
            $_SESSION['message'] = "Topic created successfully!";
            $_SESSION['message_type'] = "success";
            
            if (!empty($category_id)) {
                header("Location: category.php?id=$category_id");
            } else {
                header("Location: index.php");
            }
            exit;
        } catch (Exception $e) {
            $conn->rollBack();
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
    
    // If we got here, there were errors
    if (!empty($errors)) {
        $_SESSION['form_errors'] = $errors;
        $_SESSION['form_data'] = [
            'forum_id' => $forum_id,
            'category_id' => $category_id,
            'title' => $title,
            'message' => $message
        ];
        
        header("Location: create.php?error=1");
        exit;
    }
} else {
    // If accessed directly without form submission, redirect to create page
    header("Location: create.php");
    exit;
}

require_once '../includes/footer.php';
?>