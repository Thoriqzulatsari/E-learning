<?php
/**
 * Forum Chat AJAX Handler
 * This file handles all AJAX requests for the chat functionality
 */

// Include database connection
require_once '../includes/db_connection.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set content type to JSON
header('Content-Type: application/json');

// Get JSON request data
$request_data = json_decode(file_get_contents('php://input'), true);

// Default error response
$response = [
    'success' => false,
    'message' => 'Invalid request'
];

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $response['message'] = 'User not authenticated';
    echo json_encode($response);
    exit;
}

// Get action from request
$action = isset($request_data['action']) ? $request_data['action'] : '';

// Process request based on action
switch ($action) {
    case 'get_messages':
        $response = getMessages($request_data);
        break;
    
    case 'send_message':
        $response = sendMessage($request_data);
        break;
    
    case 'get_active_users':
        $response = getActiveUsers($request_data);
        break;
    
    case 'update_activity':
        $response = updateUserActivity($request_data);
        break;
    
    default:
        // Invalid action
        $response['message'] = 'Invalid action';
}

// Send response
echo json_encode($response);
exit;

/**
 * Get chat messages
 */
function getMessages($data) {
    global $conn;
    
    $last_id = isset($data['last_id']) ? intval($data['last_id']) : 0;
    $course_id = isset($data['course_id']) ? intval($data['course_id']) : 0;
    $user_id = isset($data['user_id']) ? intval($data['user_id']) : 0;
    
    // Validate request
    if (empty($course_id) || empty($user_id)) {
        return [
            'success' => false,
            'message' => 'Missing required parameters'
        ];
    }
    
    try {
        // Prepare query
        $stmt = $conn->prepare("
            SELECT c.*, u.username as user_name
            FROM forum_chat_messages c
            JOIN users u ON c.user_id = u.user_id
            WHERE c.course_id = ? AND c.id > ?
            ORDER BY c.timestamp ASC
            LIMIT 50
        ");
        
        $stmt->execute([$course_id, $last_id]);
        $messages = $stmt->fetchAll();
        
        return [
            'success' => true,
            'messages' => $messages
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ];
    }
}

/**
 * Send a new chat message
 */
function sendMessage($data) {
    global $conn;
    
    $course_id = isset($data['course_id']) ? intval($data['course_id']) : 0;
    $user_id = isset($data['user_id']) ? intval($data['user_id']) : 0;
    $message = isset($data['message']) ? trim($data['message']) : '';
    
    // Validate request
    if (empty($course_id) || empty($user_id) || empty($message)) {
        return [
            'success' => false,
            'message' => 'Missing required parameters'
        ];
    }
    
    // Check message length
    if (strlen($message) > 1000) {
        return [
            'success' => false,
            'message' => 'Message is too long (maximum 1000 characters)'
        ];
    }
    
    try {
        // Insert message
        $stmt = $conn->prepare("
            INSERT INTO forum_chat_messages (course_id, user_id, message, timestamp)
            VALUES (?, ?, ?, NOW())
        ");
        
        $stmt->execute([$course_id, $user_id, $message]);
        
        // Update user activity
        updateUserActivity([
            'course_id' => $course_id,
            'user_id' => $user_id
        ]);
        
        return [
            'success' => true,
            'message_id' => $conn->lastInsertId()
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ];
    }
}

/**
 * Get active users in a course chat
 */
function getActiveUsers($data) {
    global $conn;
    
    $course_id = isset($data['course_id']) ? intval($data['course_id']) : 0;
    
    // Validate request
    if (empty($course_id)) {
        return [
            'success' => false,
            'message' => 'Missing required parameters'
        ];
    }
    
    try {
        // Get users active in the last 5 minutes
        $stmt = $conn->prepare("
            SELECT a.user_id as id, u.username as name, u.role as role
            FROM forum_chat_activity a
            JOIN users u ON a.user_id = u.user_id
            WHERE a.course_id = ?
              AND a.last_activity > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
            ORDER BY u.role, u.username
        ");
        
        $stmt->execute([$course_id]);
        $users = $stmt->fetchAll();
        
        return [
            'success' => true,
            'users' => $users
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ];
    }
}

/**
 * Update user activity status
 */
function updateUserActivity($data) {
    global $conn;
    
    $course_id = isset($data['course_id']) ? intval($data['course_id']) : 0;
    $user_id = isset($data['user_id']) ? intval($data['user_id']) : 0;
    
    // Validate request
    if (empty($course_id) || empty($user_id)) {
        return [
            'success' => false,
            'message' => 'Missing required parameters'
        ];
    }
    
    try {
        // Insert or update activity record
        $stmt = $conn->prepare("
            INSERT INTO forum_chat_activity (course_id, user_id, last_activity)
            VALUES (?, ?, NOW())
            ON DUPLICATE KEY UPDATE last_activity = NOW()
        ");
        
        $stmt->execute([$course_id, $user_id]);
        
        return [
            'success' => true
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ];
    }
}