<?php
/**
 * Forum Poll Feature
 * Allows users to create and participate in polls within forum topics
 */

// Include required files
require_once '../includes/header.php';
require_once '../includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "You must be logged in to use this feature.";
    $_SESSION['message_type'] = "error";
    header("Location: ../login.php");
    exit;
}

// Default values
$action = isset($_GET['action']) ? trim($_GET['action']) : 'create';
$topic_id = isset($_GET['topic_id']) ? intval($_GET['topic_id']) : 0;
$poll_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form_action = isset($_POST['form_action']) ? trim($_POST['form_action']) : '';
    
    if ($form_action === 'create') {
        // Create a new poll
        $question = isset($_POST['question']) ? trim($_POST['question']) : '';
        $options = isset($_POST['options']) ? $_POST['options'] : [];
        $topic_id = isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
        $multiple_choice = isset($_POST['multiple_choice']) ? 1 : 0;
        $end_date = isset($_POST['end_date']) ? trim($_POST['end_date']) : null;
        
        // Validate poll data
        $errors = [];
        if (empty($question)) {
            $errors[] = "Poll question is required";
        }
        
        // Make sure we have at least 2 options
        $options = array_filter($options, function($option) {
            return !empty(trim($option));
        });
        
        if (count($options) < 2) {
            $errors[] = "Please provide at least 2 poll options";
        }
        
        // Validate topic_id
        if (empty($topic_id)) {
            $errors[] = "Topic ID is required";
        } else {
            // Verify topic exists
            $stmt = $conn->prepare("SELECT topic_id FROM forum_topics WHERE topic_id = ?");
            $stmt->execute([$topic_id]);
            if (!$stmt->fetch()) {
                $errors[] = "Invalid topic ID";
            }
        }
        
        // Process valid poll
        if (empty($errors)) {
            try {
                $conn->beginTransaction();
                
                // Create the poll
                $stmt = $conn->prepare("
                    INSERT INTO forum_polls (
                        topic_id, user_id, question, multiple_choice, 
                        end_date, created_at, updated_at
                    ) VALUES (
                        ?, ?, ?, ?, 
                        " . (!empty($end_date) ? "?" : "NULL") . ", NOW(), NOW()
                    )
                ");
                
                $params = [$topic_id, $_SESSION['user_id'], $question, $multiple_choice];
                if (!empty($end_date)) {
                    $params[] = $end_date;
                }
                
                $stmt->execute($params);
                $poll_id = $conn->lastInsertId();
                
                // Create poll options
                $stmt = $conn->prepare("
                    INSERT INTO forum_poll_options (
                        poll_id, option_text, created_at
                    ) VALUES (
                        ?, ?, NOW()
                    )
                ");
                
                foreach ($options as $option) {
                    if (!empty(trim($option))) {
                        $stmt->execute([$poll_id, trim($option)]);
                    }
                }
                
                $conn->commit();
                
                // Redirect to the topic page
                $_SESSION['message'] = "Poll created successfully";
                $_SESSION['message_type'] = "success";
                header("Location: topic.php?id=$topic_id");
                exit;
            } catch (Exception $e) {
                $conn->rollBack();
                $errors[] = "Database error: " . $e->getMessage();
            }
        }
        
        // Store errors in session
        if (!empty($errors)) {
            $_SESSION['poll_errors'] = $errors;
            $_SESSION['poll_data'] = [
                'question' => $question,
                'options' => $options,
                'multiple_choice' => $multiple_choice,
                'end_date' => $end_date
            ];
            
            // Redirect back to poll creation page
            header("Location: poll.php?action=create&topic_id=$topic_id");
            exit;
        }
    } else if ($form_action === 'vote') {
        // Vote in a poll
        $poll_id = isset($_POST['poll_id']) ? intval($_POST['poll_id']) : 0;
        $topic_id = isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
        $options = isset($_POST['options']) ? (array)$_POST['options'] : [];
        
        // Validate vote data
        $errors = [];
        if (empty($poll_id)) {
            $errors[] = "Poll ID is required";
        }
        
        if (empty($options)) {
            $errors[] = "Please select at least one option";
        }
        
        // Verify poll exists and is still active
        if (!empty($poll_id)) {
            $stmt = $conn->prepare("
                SELECT p.*, t.topic_id 
                FROM forum_polls p
                JOIN forum_topics t ON p.topic_id = t.topic_id
                WHERE p.poll_id = ?
            ");
            $stmt->execute([$poll_id]);
            $poll = $stmt->fetch();
            
            if (!$poll) {
                $errors[] = "Invalid poll ID";
            } else {
                // Check if poll has ended
                if (!empty($poll['end_date']) && strtotime($poll['end_date']) < time()) {
                    $errors[] = "This poll has ended";
                }
                
                // Set topic_id from poll data
                $topic_id = $poll['topic_id'];
                
                // Check if user has already voted and this is not a multiple-choice poll
                if (!$poll['multiple_choice']) {
                    $stmt = $conn->prepare("
                        SELECT 1 FROM forum_poll_votes
                        WHERE poll_id = ? AND user_id = ?
                    ");
                    $stmt->execute([$poll_id, $_SESSION['user_id']]);
                    
                    if ($stmt->fetch()) {
                        $errors[] = "You have already voted in this poll";
                    }
                }
            }
        }
        
        // Process valid vote
        if (empty($errors)) {
            try {
                $conn->beginTransaction();
                
                // If not multiple choice, clear previous votes from this user
                if (!$poll['multiple_choice']) {
                    $stmt = $conn->prepare("
                        DELETE FROM forum_poll_votes
                        WHERE poll_id = ? AND user_id = ?
                    ");
                    $stmt->execute([$poll_id, $_SESSION['user_id']]);
                }
                
                // Insert votes
                $stmt = $conn->prepare("
                    INSERT INTO forum_poll_votes (
                        poll_id, option_id, user_id, created_at
                    ) VALUES (
                        ?, ?, ?, NOW()
                    )
                ");
                
                foreach ($options as $option_id) {
                    $stmt->execute([$poll_id, $option_id, $_SESSION['user_id']]);
                }
                
                $conn->commit();
                
                // Redirect to the topic page
                $_SESSION['message'] = "Vote recorded successfully";
                $_SESSION['message_type'] = "success";
                header("Location: topic.php?id=$topic_id");
                exit;
            } catch (Exception $e) {
                $conn->rollBack();
                $errors[] = "Database error: " . $e->getMessage();
            }
        }
        
        // Store errors in session
        if (!empty($errors)) {
            $_SESSION['poll_errors'] = $errors;
            
            // Redirect back to topic page
            header("Location: topic.php?id=$topic_id");
            exit;
        }
    }
}

// Get topic details if topic_id is provided
$topic = null;
if ($topic_id > 0) {
    $stmt = $conn->prepare("SELECT * FROM forum_topics WHERE topic_id = ?");
    $stmt->execute([$topic_id]);
    $topic = $stmt->fetch();
}

// Get poll details if poll_id is provided
$poll = null;
if ($poll_id > 0) {
    $stmt = $conn->prepare("
        SELECT p.*, t.title as topic_title, u.username as creator_name
        FROM forum_polls p
        JOIN forum_topics t ON p.topic_id = t.topic_id
        JOIN users u ON p.user_id = u.user_id
        WHERE p.poll_id = ?
    ");
    $stmt->execute([$poll_id]);
    $poll = $stmt->fetch();
    
    // Get poll options
    if ($poll) {
        $stmt = $conn->prepare("
            SELECT po.*, 
                (SELECT COUNT(*) FROM forum_poll_votes pv WHERE pv.option_id = po.option_id) as votes_count,
                (SELECT COUNT(*) FROM forum_poll_votes pv WHERE pv.option_id = po.option_id AND pv.user_id = ?) as user_voted
            FROM forum_poll_options po
            WHERE po.poll_id = ?
            ORDER BY po.option_id
        ");
        $stmt->execute([$_SESSION['user_id'], $poll_id]);
        $poll['options'] = $stmt->fetchAll();
        
        // Get total votes
        $stmt = $conn->prepare("
            SELECT COUNT(*) as total_votes 
            FROM forum_poll_votes 
            WHERE poll_id = ?
        ");
        $stmt->execute([$poll_id]);
        $result = $stmt->fetch();
        $poll['total_votes'] = $result['total_votes'];
        
        // Check if user has voted in this poll
        $stmt = $conn->prepare("
            SELECT 1 FROM forum_poll_votes
            WHERE poll_id = ? AND user_id = ?
        ");
        $stmt->execute([$poll_id, $_SESSION['user_id']]);
        $poll['user_has_voted'] = (bool)$stmt->fetch();
    }
}

// Get stored errors and form data
$errors = isset($_SESSION['poll_errors']) ? $_SESSION['poll_errors'] : [];
$form_data = isset($_SESSION['poll_data']) ? $_SESSION['poll_data'] : [];

// Clear session data
unset($_SESSION['poll_errors']);
unset($_SESSION['poll_data']);

// Page title
$page_title = ($action === 'create') ? "Create Poll" : (($action === 'results') ? "Poll Results" : "View Poll");
?>

<div class="container my-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Forums</a></li>
            <?php if ($topic): ?>
            <li class="breadcrumb-item"><a href="topic.php?id=<?php echo $topic['topic_id']; ?>"><?php echo htmlspecialchars($topic['title']); ?></a></li>
            <?php elseif ($poll): ?>
            <li class="breadcrumb-item"><a href="topic.php?id=<?php echo $poll['topic_id']; ?>"><?php echo htmlspecialchars($poll['topic_title']); ?></a></li>
            <?php endif; ?>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $page_title; ?></li>
        </ol>
    </nav>
    
    <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <h5>Please correct the following errors:</h5>
        <ul class="mb-0">
            <?php foreach ($errors as $error): ?>
            <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <?php if ($action === 'create'): ?>
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h1 class="h4 mb-0">Create a New Poll</h1>
        </div>
        <div class="card-body">
            <?php if (!$topic): ?>
            <div class="alert alert-danger">Invalid topic ID</div>
            <?php else: ?>
            <form method="POST" action="poll.php">
                <input type="hidden" name="form_action" value="create">
                <input type="hidden" name="topic_id" value="<?php echo $topic_id; ?>">
                
                <div class="mb-3">
                    <label for="question" class="form-label">Poll Question</label>
                    <input type="text" class="form-control" id="question" name="question" value="<?php echo isset($form_data['question']) ? htmlspecialchars($form_data['question']) : ''; ?>" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Poll Options</label>
                    <div id="poll-options">
                        <?php
                        $options = isset($form_data['options']) ? $form_data['options'] : ['', ''];
                        foreach ($options as $i => $option):
                        ?>
                        <div class="input-group mb-2">
                            <input type="text" class="form-control" name="options[]" value="<?php echo htmlspecialchars($option); ?>" placeholder="Option <?php echo $i + 1; ?>" <?php echo ($i < 2) ? 'required' : ''; ?>>
                            <?php if ($i >= 2): ?>
                            <button type="button" class="btn btn-outline-danger remove-option">
                                <i class="fas fa-times"></i>
                            </button>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <button type="button" id="add-option" class="btn btn-sm btn-outline-primary mt-1">
                        <i class="fas fa-plus"></i> Add Option
                    </button>
                </div>
                
                <div class="mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="multiple_choice" name="multiple_choice" <?php echo isset($form_data['multiple_choice']) && $form_data['multiple_choice'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="multiple_choice">
                            Allow users to select multiple options
                        </label>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label for="end_date" class="form-label">End Date (Optional)</label>
                    <input type="datetime-local" class="form-control" id="end_date" name="end_date" value="<?php echo isset($form_data['end_date']) ? htmlspecialchars($form_data['end_date']) : ''; ?>">
                    <div class="form-text">If set, the poll will close at this date and time. Leave blank for no end date.</div>
                </div>
                
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">Create Poll</button>
                    <a href="topic.php?id=<?php echo $topic_id; ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
    
    <?php elseif ($action === 'results' && $poll): ?>
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h1 class="h4 mb-0">Poll Results</h1>
        </div>
        <div class="card-body">
            <h2 class="poll-question h5 mb-4"><?php echo htmlspecialchars($poll['question']); ?></h2>
            
            <div class="poll-results">
                <?php foreach ($poll['options'] as $option): ?>
                <div class="poll-result">
                    <div class="poll-result-text">
                        <span><?php echo htmlspecialchars($option['option_text']); ?></span>
                        <span>
                            <?php
                            $votes = intval($option['votes_count']);
                            $percentage = ($poll['total_votes'] > 0) ? round(($votes / $poll['total_votes']) * 100) : 0;
                            echo "$votes vote" . ($votes !== 1 ? 's' : '') . " ($percentage%)";
                            ?>
                        </span>
                    </div>
                    <div class="poll-result-bar">
                        <div class="poll-result-progress" style="width: <?php echo $percentage; ?>%"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="poll-footer">
                <div>
                    <?php 
                    $total_votes = intval($poll['total_votes']);
                    echo "Total: $total_votes vote" . ($total_votes !== 1 ? 's' : '');
                    
                    if (!empty($poll['end_date'])) {
                        $end_date = strtotime($poll['end_date']);
                        if ($end_date > time()) {
                            echo " • Ends " . date('M j, Y \a\t g:i a', $end_date);
                        } else {
                            echo " • Ended " . date('M j, Y', $end_date);
                        }
                    }
                    ?>
                </div>
                
                <div class="poll-actions">
                    <a href="topic.php?id=<?php echo $poll['topic_id']; ?>" class="btn btn-sm btn-primary">Back to Topic</a>
                    
                    <?php if (!$poll['user_has_voted'] && (empty($poll['end_date']) || strtotime($poll['end_date']) > time())): ?>
                    <a href="poll.php?action=vote&id=<?php echo $poll['poll_id']; ?>" class="btn btn-sm btn-success">Vote</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <?php elseif ($action === 'vote' && $poll): ?>
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h1 class="h4 mb-0">Vote in Poll</h1>
        </div>
        <div class="card-body">
            <?php if (!empty($poll['end_date']) && strtotime($poll['end_date']) < time()): ?>
            <div class="alert alert-warning">This poll has ended.</div>
            <a href="topic.php?id=<?php echo $poll['topic_id']; ?>" class="btn btn-primary">Back to Topic</a>
            
            <?php elseif ($poll['user_has_voted'] && !$poll['multiple_choice']): ?>
            <div class="alert alert-info">You have already voted in this poll.</div>
            <div class="d-flex gap-2">
                <a href="poll.php?action=results&id=<?php echo $poll['poll_id']; ?>" class="btn btn-primary">View Results</a>
                <a href="topic.php?id=<?php echo $poll['topic_id']; ?>" class="btn btn-secondary">Back to Topic</a>
            </div>
            
            <?php else: ?>
            <h2 class="poll-question h5 mb-4"><?php echo htmlspecialchars($poll['question']); ?></h2>
            
            <form method="POST" action="poll.php">
                <input type="hidden" name="form_action" value="vote">
                <input type="hidden" name="poll_id" value="<?php echo $poll['poll_id']; ?>">
                <input type="hidden" name="topic_id" value="<?php echo $poll['topic_id']; ?>">
                
                <div class="poll-options mb-4">
                    <?php foreach ($poll['options'] as $option): ?>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="<?php echo $poll['multiple_choice'] ? 'checkbox' : 'radio'; ?>" 
                               name="options<?php echo $poll['multiple_choice'] ? '[]' : ''; ?>" 
                               value="<?php echo $option['option_id']; ?>" 
                               id="option_<?php echo $option['option_id']; ?>"
                               <?php echo $option['user_voted'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="option_<?php echo $option['option_id']; ?>">
                            <?php echo htmlspecialchars($option['option_text']); ?>
                        </label>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">Submit Vote</button>
                    <a href="poll.php?action=results&id=<?php echo $poll['poll_id']; ?>" class="btn btn-outline-primary">View Results</a>
                    <a href="topic.php?id=<?php echo $poll['topic_id']; ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
    
    <?php else: ?>
    <div class="alert alert-danger">
        Invalid action or poll ID
    </div>
    <a href="index.php" class="btn btn-primary">Back to Forums</a>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add option button
    const addOptionBtn = document.getElementById('add-option');
    if (addOptionBtn) {
        addOptionBtn.addEventListener('click', function() {
            const optionsContainer = document.getElementById('poll-options');
            const optionCount = optionsContainer.children.length;
            
            const optionGroup = document.createElement('div');
            optionGroup.className = 'input-group mb-2';
            optionGroup.innerHTML = `
                <input type="text" class="form-control" name="options[]" placeholder="Option ${optionCount + 1}">
                <button type="button" class="btn btn-outline-danger remove-option">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            optionsContainer.appendChild(optionGroup);
            
            // Focus the new input
            const newInput = optionGroup.querySelector('input');
            newInput.focus();
        });
    }
    
    // Remove option buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-option') || e.target.closest('.remove-option')) {
            const button = e.target.classList.contains('remove-option') ? e.target : e.target.closest('.remove-option');
            const optionGroup = button.parentElement;
            optionGroup.remove();
        }
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>
