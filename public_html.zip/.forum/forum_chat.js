/**
 * Forum Chat System
 * This JavaScript handles the real-time chat functionality for the forum
 */

class ForumChat {
    constructor(options = {}) {
        // Default settings
        this.settings = {
            chatContainer: '#chat-container',
            messageContainer: '#chat-messages',
            userList: '#chat-users',
            inputField: '#chat-input',
            sendButton: '#chat-send',
            toggleButton: '#chat-toggle',
            refreshInterval: 5000, // ms
            maxMessages: 100,
            userId: null,
            userName: null,
            userRole: null,
            courseName: null,
            courseId: null,
            ...options
        };

        // State variables
        this.isMinimized = false;
        this.isInitialized = false;
        this.lastMessageId = 0;
        this.activeUsers = [];
        this.chatEndpoint = `${window.location.origin}/mini-elearning/forum/chat_ajax.php`;

        // Initialize if user is logged in
        if (this.settings.userId) {
            this.init();
        }
    }

    /**
     * Initialize the chat system
     */
    init() {
        if (this.isInitialized) return;
        
        // Check if elements exist in the DOM
        const chatContainer = document.querySelector(this.settings.chatContainer);
        if (!chatContainer) {
            console.error('Chat container not found');
            return;
        }

        // Set up event listeners
        this.setupEventListeners();
        
        // Initial message load
        this.loadMessages();
        
        // Set up refresh interval
        this.refreshInterval = setInterval(() => {
            this.loadMessages();
            this.loadActiveUsers();
        }, this.settings.refreshInterval);
        
        // Mark as initialized
        this.isInitialized = true;
        
        // Load active users
        this.loadActiveUsers();
        
        // Notify server that user is active
        this.updateUserActivity();
        
        console.log('Chat system initialized');
    }

    /**
     * Set up event listeners for the chat controls
     */
    setupEventListeners() {
        // Send button
        const sendButton = document.querySelector(this.settings.sendButton);
        if (sendButton) {
            sendButton.addEventListener('click', e => {
                e.preventDefault();
                this.sendMessage();
            });
        }
        
        // Input field (enter key)
        const inputField = document.querySelector(this.settings.inputField);
        if (inputField) {
            inputField.addEventListener('keypress', e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }
        
        // Toggle chat button
        const toggleButton = document.querySelector(this.settings.toggleButton);
        if (toggleButton) {
            toggleButton.addEventListener('click', e => {
                e.preventDefault();
                this.toggleChat();
            });
        }
        
        // Window visibility change
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                this.loadMessages();
                this.loadActiveUsers();
                this.updateUserActivity();
            }
        });
    }

    /**
     * Load chat messages from the server
     */
    loadMessages() {
        // Prepare data for the request
        const data = {
            action: 'get_messages',
            last_id: this.lastMessageId,
            course_id: this.settings.courseId,
            user_id: this.settings.userId
        };
        
        // Send AJAX request
        fetch(this.chatEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.messages.length > 0) {
                this.renderMessages(data.messages);
                // Update last message ID if we got new messages
                if (data.messages.length > 0) {
                    this.lastMessageId = data.messages[data.messages.length - 1].id;
                }
            }
        })
        .catch(error => {
            console.error('Error loading messages:', error);
        });
    }

    /**
     * Load active users in the chat
     */
    loadActiveUsers() {
        // Prepare data for the request
        const data = {
            action: 'get_active_users',
            course_id: this.settings.courseId,
            user_id: this.settings.userId
        };
        
        // Send AJAX request
        fetch(this.chatEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.activeUsers = data.users;
                this.renderActiveUsers();
            }
        })
        .catch(error => {
            console.error('Error loading active users:', error);
        });
    }

    /**
     * Update user activity status
     */
    updateUserActivity() {
        // Prepare data for the request
        const data = {
            action: 'update_activity',
            course_id: this.settings.courseId,
            user_id: this.settings.userId
        };
        
        // Send AJAX request
        fetch(this.chatEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .catch(error => {
            console.error('Error updating activity:', error);
        });
    }

    /**
     * Send a new message
     */
    sendMessage() {
        const inputField = document.querySelector(this.settings.inputField);
        if (!inputField) return;
        
        const message = inputField.value.trim();
        if (message === '') return;
        
        // Clear input field
        inputField.value = '';
        
        // Prepare data for the request
        const data = {
            action: 'send_message',
            course_id: this.settings.courseId,
            user_id: this.settings.userId,
            user_name: this.settings.userName,
            message: message
        };
        
        // Send AJAX request
        fetch(this.chatEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Immediately load new messages
                this.loadMessages();
            } else {
                console.error('Error sending message:', data.message);
            }
        })
        .catch(error => {
            console.error('Error sending message:', error);
        });
    }

    /**
     * Render messages in the chat container
     */
    renderMessages(messages) {
        const messageContainer = document.querySelector(this.settings.messageContainer);
        if (!messageContainer) return;
        
        // Append new messages
        messages.forEach(message => {
            // Create message element
            const messageEl = document.createElement('div');
            messageEl.className = 'chat-message';
            if (message.user_id == this.settings.userId) {
                messageEl.classList.add('chat-message-self');
            }
            
            // Format timestamp
            const date = new Date(message.timestamp);
            const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            
            // Create message content
            messageEl.innerHTML = `
                <div class="chat-message-header">
                    <span class="chat-message-username">${message.user_name}</span>
                    <span class="chat-message-time">${timeStr}</span>
                </div>
                <div class="chat-message-content">${this.formatMessageText(message.message)}</div>
            `;
            
            // Add to container
            messageContainer.appendChild(messageEl);
        });
        
        // Scroll to bottom
        messageContainer.scrollTop = messageContainer.scrollHeight;
        
        // Limit number of messages in DOM
        this.pruneMessages();
    }

    /**
     * Format message text with links, emojis, etc.
     */
    formatMessageText(text) {
        // Convert URLs to links
        text = text.replace(
            /(https?:\/\/[^\s]+)/g, 
            '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
        );
        
        // Convert line breaks
        text = text.replace(/\n/g, '<br>');
        
        return text;
    }

    /**
     * Remove old messages to keep DOM size manageable
     */
    pruneMessages() {
        const messageContainer = document.querySelector(this.settings.messageContainer);
        if (!messageContainer) return;
        
        const messages = messageContainer.querySelectorAll('.chat-message');
        if (messages.length > this.settings.maxMessages) {
            const deleteCount = messages.length - this.settings.maxMessages;
            for (let i = 0; i < deleteCount; i++) {
                messageContainer.removeChild(messages[i]);
            }
        }
    }

    /**
     * Render active users in the sidebar
     */
    renderActiveUsers() {
        const userList = document.querySelector(this.settings.userList);
        if (!userList) return;
        
        // Clear existing list
        userList.innerHTML = '';
        
        // Add user count
        const countEl = document.createElement('div');
        countEl.className = 'chat-user-count';
        countEl.textContent = `${this.activeUsers.length} active user${this.activeUsers.length !== 1 ? 's' : ''}`;
        userList.appendChild(countEl);
        
        // Add each user
        this.activeUsers.forEach(user => {
            const userEl = document.createElement('div');
            userEl.className = 'chat-user';
            
            // Highlight current user
            if (user.id == this.settings.userId) {
                userEl.classList.add('chat-user-self');
            }
            
            // Add role badge for instructors/admins
            let roleBadge = '';
            if (user.role === 'instructor') {
                roleBadge = '<span class="chat-role-badge instructor">Instructor</span>';
            } else if (user.role === 'admin') {
                roleBadge = '<span class="chat-role-badge admin">Admin</span>';
            }
            
            userEl.innerHTML = `
                <div class="chat-user-avatar">
                    ${user.name.charAt(0).toUpperCase()}
                </div>
                <div class="chat-user-info">
                    <div class="chat-user-name">${user.name} ${roleBadge}</div>
                    <div class="chat-user-status">Active</div>
                </div>
            `;
            
            userList.appendChild(userEl);
        });
    }

    /**
     * Toggle the chat between minimized and expanded states
     */
    toggleChat() {
        const chatContainer = document.querySelector(this.settings.chatContainer);
        if (!chatContainer) return;
        
        this.isMinimized = !this.isMinimized;
        
        if (this.isMinimized) {
            chatContainer.classList.add('chat-minimized');
        } else {
            chatContainer.classList.remove('chat-minimized');
            // Scroll to bottom when maximizing
            const messageContainer = document.querySelector(this.settings.messageContainer);
            if (messageContainer) {
                messageContainer.scrollTop = messageContainer.scrollHeight;
            }
        }
        
        // Update toggle button text
        const toggleButton = document.querySelector(this.settings.toggleButton);
        if (toggleButton) {
            toggleButton.innerHTML = this.isMinimized ? 
                '<i class="fas fa-expand-alt"></i>' : 
                '<i class="fas fa-compress-alt"></i>';
        }
    }

    /**
     * Clean up resources when chat is no longer needed
     */
    destroy() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
        this.isInitialized = false;
    }
}

// Initialize chat when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Get user info from data attributes on body
    const body = document.body;
    const userId = body.dataset.userId;
    const userName = body.dataset.userName;
    const userRole = body.dataset.userRole;
    
    // Get course info if on a course page
    const courseElement = document.querySelector('[data-course-id]');
    const courseId = courseElement ? courseElement.dataset.courseId : null;
    const courseName = courseElement ? courseElement.dataset.courseName : null;
    
    // Only initialize if we have a user ID and course ID
    if (userId && courseId) {
        window.forumChat = new ForumChat({
            userId,
            userName,
            userRole,
            courseId,
            courseName
        });
    }
});