<?php
/**
 * Course Chat Component
 * 
 * This component can be included in any course page to enable real-time chat
 * It requires that the user is authenticated and that a course_id is defined
 */

// Verify that user is logged in
if (!isset($_SESSION['user_id'])) {
    return;
}

// Verify that course_id is defined
if (!isset($course_id) || empty($course_id)) {
    return;
}

// Get course details
$stmt = $conn->prepare("SELECT title FROM courses WHERE course_id = ?");
$stmt->execute([$course_id]);
$course = $stmt->fetch();

if (!$course) {
    return;
}

// Generate a unique container ID
$chat_container_id = 'chat-' . $course_id;
?>

<!-- Chat Container -->
<div id="<?php echo $chat_container_id; ?>" class="chat-container chat-minimized">
    <div class="chat-header">
        <h5 class="chat-title"><?php echo htmlspecialchars($course['title']); ?> Chat</h5>
        <div class="chat-controls">
            <button id="<?php echo $chat_container_id; ?>-toggle" class="chat-control chat-toggle" title="Toggle chat">
                <i class="fas fa-expand-alt"></i>
            </button>
        </div>
    </div>
    <div class="chat-body">
        <div id="<?php echo $chat_container_id; ?>-users" class="chat-users">
            <!-- Active users will be loaded here -->
            <div class="chat-user-count">Loading users...</div>
        </div>
        <div id="<?php echo $chat_container_id; ?>-messages" class="chat-messages">
            <!-- Messages will be loaded here -->
            <div class="text-center py-4 text-muted">
                <div class="spinner-border spinner-border-sm" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading messages...</p>
            </div>
        </div>
    </div>
    <div class="chat-footer">
        <input type="text" id="<?php echo $chat_container_id; ?>-input" class="chat-input" placeholder="Type a message..." />
        <button id="<?php echo $chat_container_id; ?>-send" class="chat-send">
            <i class="fas fa-paper-plane"></i>
        </button>
    </div>
</div>

<!-- Chat Initialization -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize chat when forum-chat.js is loaded
    if (typeof ForumChat !== 'undefined') {
        window.courseChat = new ForumChat({
            chatContainer: '#<?php echo $chat_container_id; ?>',
            messageContainer: '#<?php echo $chat_container_id; ?>-messages',
            userList: '#<?php echo $chat_container_id; ?>-users',
            inputField: '#<?php echo $chat_container_id; ?>-input',
            sendButton: '#<?php echo $chat_container_id; ?>-send',
            toggleButton: '#<?php echo $chat_container_id; ?>-toggle',
            userId: <?php echo $_SESSION['user_id']; ?>,
            userName: <?php echo json_encode($_SESSION['username'] ?? ($_SESSION['full_name'] ?? 'User')); ?>,
            userRole: <?php echo json_encode($_SESSION['role'] ?? 'student'); ?>,
            courseId: <?php echo $course_id; ?>,
            courseName: <?php echo json_encode($course['title']); ?>
        });
    } else {
        console.error('ForumChat class not found. Make sure forum-chat.js is loaded.');
    }
});
</script>