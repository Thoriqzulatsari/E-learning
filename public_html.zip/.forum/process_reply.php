<?php
// forum/process_reply.php
require_once '../includes/header.php';
require_once '../includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "You must be logged in to post a reply.";
    $_SESSION['message_type'] = "error";
    header("Location: ../login.php");
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    $topic_id = isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';
    $user_id = $_SESSION['user_id'];
    
    // Basic validation
    $errors = [];
    if (empty($topic_id)) {
        $errors[] = "Invalid topic";
    }
    if (empty($content)) {
        $errors[] = "Reply content is required";
    }
    
    // Verify the topic exists
    if (!empty($topic_id)) {
        $topic = getTopicById($topic_id);
        if (!$topic) {
            $errors[] = "Topic not found";
        }
    }
    
    // Process file uploads if any
    $attachments = [];
    if (!empty($_FILES['attachments']['name'][0])) {
        $upload_dir = '../uploads/forum/';
        
        // Create directory if it doesn't exist
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        // Define allowed file types
        $allowed_types = [
            'image/jpeg', 'image/png', 'image/gif', 
            'application/pdf', 'application/msword', 
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'text/plain'
        ];
        
        foreach ($_FILES['attachments']['name'] as $key => $name) {
            if ($_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK) {
                $tmp_name = $_FILES['attachments']['tmp_name'][$key];
                $file_type = $_FILES['attachments']['type'][$key];
                
                // Sanitize filename
                $name = preg_replace('/[^a-zA-Z0-9._-]/', '', basename($name));
                
                // Create unique filename
                $filename = uniqid('reply_') . '_' . $name;
                $destination = $upload_dir . $filename;
                
                // Validate file type
                if (!in_array($file_type, $allowed_types)) {
                    $errors[] = "File type not allowed for: $name";
                    continue;
                }
                
                // Check file size (5MB max)
                if ($_FILES['attachments']['size'][$key] > 5242880) {
                    $errors[] = "File $name exceeds maximum size (5MB)";
                    continue;
                }
                
                // Move the uploaded file
                if (move_uploaded_file($tmp_name, $destination)) {
                    $attachments[] = [
                        'filename' => $filename,
                        'original_filename' => $_FILES['attachments']['name'][$key],
                        'filesize' => $_FILES['attachments']['size'][$key],
                        'file_type' => $file_type
                    ];
                } else {
                    $errors[] = "Failed to upload file: $name";
                }
            } else if ($_FILES['attachments']['error'][$key] !== UPLOAD_ERR_NO_FILE) {
                // Map error codes to messages
                $upload_errors = [
                    UPLOAD_ERR_INI_SIZE => "File exceeds the upload_max_filesize directive",
                    UPLOAD_ERR_FORM_SIZE => "File exceeds the MAX_FILE_SIZE directive from the form",
                    UPLOAD_ERR_PARTIAL => "File was only partially uploaded",
                    UPLOAD_ERR_NO_TMP_DIR => "Missing a temporary folder",
                    UPLOAD_ERR_CANT_WRITE => "Failed to write file to disk",
                    UPLOAD_ERR_EXTENSION => "A PHP extension stopped the file upload"
                ];
                
                $error_code = $_FILES['attachments']['error'][$key];
                $error_message = isset($upload_errors[$error_code]) ? $upload_errors[$error_code] : "Unknown upload error";
                $errors[] = "Error uploading $name: $error_message";
            }
        }
    }
    
    // If there are no errors, save the reply
    if (empty($errors)) {
        try {
            global $conn;
            $conn->beginTransaction();
            
            // Insert the reply
            $stmt = $conn->prepare("
                INSERT INTO forum_replies 
                    (topic_id, user_id, content, created_at) 
                VALUES 
                    (?, ?, ?, NOW())
            ");
            $stmt->execute([$topic_id, $user_id, $content]);
            $reply_id = $conn->lastInsertId();
            
            // Update topic's last reply info
            $stmt = $conn->prepare("
                UPDATE forum_topics 
                SET last_reply_at = NOW(), 
                    last_reply_user_id = ? 
                WHERE topic_id = ?
            ");
            $stmt->execute([$user_id, $topic_id]);
            
            // Insert attachments if any
            if (!empty($attachments)) {
                $stmt = $conn->prepare("
                    INSERT INTO forum_attachments 
                        (reply_id, user_id, filename, original_filename, filesize, file_type, uploaded_at) 
                    VALUES 
                        (?, ?, ?, ?, ?, ?, NOW())
                ");
                
                foreach ($attachments as $file) {
                    $stmt->execute([
                        $reply_id, 
                        $user_id, 
                        $file['filename'], 
                        $file['original_filename'], 
                        $file['filesize'], 
                        $file['file_type']
                    ]);
                }
            }
            
            $conn->commit();
            
            // Update read status for the user
            updateTopicReadStatus($user_id, $topic_id);
            
            // Redirect to the topic page with a success message
            $_SESSION['message'] = "Reply posted successfully!";
            $_SESSION['message_type'] = "success";
            header("Location: topic.php?id=$topic_id");
            exit;
        } catch (Exception $e) {
            $conn->rollBack();
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
    
    // If we got here, there were errors
    if (!empty($errors)) {
        $_SESSION['form_errors'] = $errors;
        $_SESSION['form_data'] = [
            'content' => $content
        ];
        
        header("Location: topic.php?id=$topic_id&error=1");
        exit;
    }
} else {
    // If accessed directly without form submission, redirect to forums
    header("Location: index.php");
    exit;
}

require_once '../includes/footer.php';
?>