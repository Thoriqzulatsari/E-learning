<?php
/**
 * Forum Content Generator
 * A utility to help users generate high-quality forum content
 */

// Include required files
require_once '../includes/header.php';
require_once '../includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "You must be logged in to use this feature.";
    $_SESSION['message_type'] = "error";
    header("Location: ../login.php");
    exit;
}

// Default values
$page_title = "Content Generator";
$content_type = isset($_GET['type']) ? trim($_GET['type']) : 'topic';
$return_to = isset($_GET['return_to']) ? trim($_GET['return_to']) : '';
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : 0;
$topic_id = isset($_GET['topic_id']) ? intval($_GET['topic_id']) : 0;

// Get course name if course_id is provided
$course_name = '';
if ($course_id > 0) {
    $stmt = $conn->prepare("SELECT title FROM courses WHERE course_id = ?");
    $stmt->execute([$course_id]);
    $course = $stmt->fetch();
    if ($course) {
        $course_name = $course['title'];
    }
}

// Get category name if category_id is provided
$category_name = '';
if ($category_id > 0) {
    $stmt = $conn->prepare("SELECT category_name FROM forum_categories WHERE category_id = ?");
    $stmt->execute([$category_id]);
    $category = $stmt->fetch();
    if ($category) {
        $category_name = $category['category_name'];
    }
}

// Get topic title if topic_id is provided
$topic_title = '';
if ($topic_id > 0) {
    $stmt = $conn->prepare("SELECT title FROM forum_topics WHERE topic_id = ?");
    $stmt->execute([$topic_id]);
    $topic = $stmt->fetch();
    if ($topic) {
        $topic_title = $topic['title'];
    }
}

// Generate content if form was submitted
$generated_content = '';
$generated_title = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $prompt = isset($_POST['prompt']) ? trim($_POST['prompt']) : '';
    $generate_type = isset($_POST['generate_type']) ? trim($_POST['generate_type']) : 'topic';
    $tone = isset($_POST['tone']) ? trim($_POST['tone']) : 'neutral';
    $length = isset($_POST['length']) ? trim($_POST['length']) : 'medium';
    
    // Include related information
    $context = '';
    if ($course_name) {
        $context .= "Course: $course_name\n";
    }
    if ($category_name) {
        $context .= "Category: $category_name\n";
    }
    if ($topic_title && $generate_type === 'reply') {
        $context .= "Topic: $topic_title\n";
    }
    
    // Generate the content based on the inputs
    if (!empty($prompt)) {
        list($generated_title, $generated_content) = generateContent($prompt, $generate_type, $tone, $length, $context);
    }
}

/**
 * Generate content based on user inputs
 * 
 * This would typically call an AI service for content generation. 
 * For this example, we're using predefined templates.
 */
function generateContent($prompt, $type, $tone, $length, $context) {
    // Define length parameters
    $lengths = [
        'short' => ['paragraphs' => 1, 'sentences' => 3],
        'medium' => ['paragraphs' => 2, 'sentences' => 5],
        'long' => ['paragraphs' => 4, 'sentences' => 7]
    ];
    
    $lengthParams = $lengths[$length] ?? $lengths['medium'];
    
    // Generate a title if it's a topic
    $title = '';
    if ($type === 'topic') {
        // Extract keywords from prompt
        $keywords = array_filter(
            explode(' ', preg_replace('/[^\w\s]/', '', strtolower($prompt))),
            function($word) {
                return strlen($word) > 3 && !in_array($word, ['about', 'what', 'where', 'when', 'which', 'that', 'this', 'these', 'those', 'with']);
            }
        );
        
        // Select 2-3 random keywords
        shuffle($keywords);
        $selectedKeywords = array_slice($keywords, 0, min(3, count($keywords)));
        
        // Generate title phrases based on tone
        $titlePhrases = [
            'formal' => [
                'An Analysis of', 'Exploring the Concept of', 'Understanding', 
                'The Importance of', 'A Comprehensive Guide to', 'Examining'
            ],
            'neutral' => [
                'Discussion on', 'Thoughts about', 'Let\'s talk about',
                'Question about', 'Help with', 'Ideas for'
            ],
            'friendly' => [
                'Anyone else excited about', 'My experience with', 'Fun facts about',
                'Need advice on', 'What do you think about', 'Share your thoughts on'
            ],
            'professional' => [
                'Best practices for', 'Case study:', 'Professional approach to',
                'Industry standards for', 'Optimizing your', 'Framework for'
            ]
        ];
        
        // Select a phrase based on tone
        $phrases = $titlePhrases[$tone] ?? $titlePhrases['neutral'];
        $phrase = $phrases[array_rand($phrases)];
        
        // Combine phrase and keywords into a title
        $title = $phrase . ' ' . implode(' ', $selectedKeywords);
        $title = ucfirst($title);
    }
    
    // Generate content
    $content = '';
    $paragraphs = [];
    
    // Create sample paragraphs based on tone and length
    $sentenceTemplates = [
        'formal' => [
            'It is important to consider {keyword} when discussing this topic.',
            'Research indicates that {keyword} plays a significant role in this context.',
            'The concept of {keyword} has been extensively studied in the literature.',
            'Professionals in the field often emphasize the importance of {keyword}.',
            'Various studies have demonstrated that {keyword} contributes significantly to outcomes.',
            'When analyzing {keyword}, one must consider multiple perspectives.',
            'Current evidence suggests that {keyword} is a critical factor to consider.',
            'Experts generally agree that {keyword} represents a fundamental aspect of this domain.'
        ],
        'neutral' => [
            'I think {keyword} is an interesting aspect to explore.',
            'Many people consider {keyword} to be relevant to this discussion.',
            '{keyword} seems to be a common element in these situations.',
            'I\'ve noticed that {keyword} appears frequently in related contexts.',
            'When we look at {keyword}, we can see several patterns emerging.',
            'There are different ways to approach {keyword} in this context.',
            'I wonder how others feel about the role of {keyword} here.',
            'It seems that {keyword} affects various aspects of this topic.'
        ],
        'friendly' => [
            'I\'m really excited about {keyword}! Anyone else feel the same?',
            'Hey everyone! What do you all think about {keyword}?',
            'I\'ve been exploring {keyword} recently and it\'s been awesome!',
            'Does anyone have tips for dealing with {keyword}? I\'d love to hear them!',
            'I find {keyword} fascinating - what has your experience been?',
            'I\'m new to {keyword} and would appreciate any advice!',
            'Have you tried working with {keyword}? I\'d love to hear your stories!',
            'I think {keyword} is super important for all of us to understand.'
        ],
        'professional' => [
            'From a professional standpoint, {keyword} represents a key consideration.',
            'Industry best practices highlight the significance of {keyword}.',
            'When implementing solutions, it\'s crucial to address {keyword} effectively.',
            'Professionals should carefully evaluate {keyword} in their approach.',
            'Effective management of {keyword} can lead to improved outcomes.',
            'The strategic importance of {keyword} cannot be overstated in this context.',
            'Organizations that prioritize {keyword} often outperform their peers.',
            'A methodical approach to {keyword} is recommended for optimal results.'
        ]
    ];
    
    // Extract keywords from prompt for content generation
    $contentKeywords = array_filter(
        explode(' ', preg_replace('/[^\w\s]/', '', strtolower($prompt))),
        function($word) {
            return strlen($word) > 3;
        }
    );
    
    if (empty($contentKeywords)) {
        $contentKeywords = ['topic', 'concept', 'idea', 'question'];
    }
    
    // Get sentence templates for selected tone
    $templates = $sentenceTemplates[$tone] ?? $sentenceTemplates['neutral'];
    
    // Generate paragraphs
    for ($p = 0; $p < $lengthParams['paragraphs']; $p++) {
        $sentences = [];
        for ($s = 0; $s < $lengthParams['sentences']; $s++) {
            $template = $templates[array_rand($templates)];
            $keyword = $contentKeywords[array_rand($contentKeywords)];
            $sentences[] = str_replace('{keyword}', $keyword, $template);
        }
        $paragraphs[] = implode(' ', $sentences);
    }
    
    // Add closing for forum post
    $closings = [
        'formal' => 'In conclusion, I welcome your thoughts on this matter.',
        'neutral' => 'What do you think about this? I\'d like to hear your perspectives.',
        'friendly' => 'I\'d love to hear what everyone else thinks! Please share your experiences!',
        'professional' => 'I invite colleagues to share their insights on this topic.'
    ];
    
    $closing = $closings[$tone] ?? $closings['neutral'];
    $paragraphs[] = $closing;
    
    // Combine paragraphs into content
    $content = implode("\n\n", $paragraphs);
    
    return [$title, $content];
}
?>

<div class="container my-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Forums</a></li>
            <?php if ($course_id > 0): ?>
            <li class="breadcrumb-item"><a href="course_forum.php?id=<?php echo $course_id; ?>"><?php echo htmlspecialchars($course_name); ?> Forum</a></li>
            <?php elseif ($category_id > 0): ?>
            <li class="breadcrumb-item"><a href="category.php?id=<?php echo $category_id; ?>"><?php echo htmlspecialchars($category_name); ?></a></li>
            <?php endif; ?>
            <?php if ($topic_id > 0): ?>
            <li class="breadcrumb-item"><a href="topic.php?id=<?php echo $topic_id; ?>"><?php echo htmlspecialchars($topic_title); ?></a></li>
            <?php endif; ?>
            <li class="breadcrumb-item active" aria-current="page">Content Generator</li>
        </ol>
    </nav>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h1 class="h3 mb-0">Forum Content Generator</h1>
                </div>
                <div class="card-body">
                    <p class="lead">Let our content generator help you create high-quality forum content.</p>
                    
                    <form method="POST" action="">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="generate_type" class="form-label">I want to generate a:</label>
                                <select class="form-select" id="generate_type" name="generate_type">
                                    <option value="topic" <?php echo ($content_type === 'topic') ? 'selected' : ''; ?>>New Topic</option>
                                    <option value="reply" <?php echo ($content_type === 'reply') ? 'selected' : ''; ?>>Reply to Topic</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="tone" class="form-label">Tone:</label>
                                <select class="form-select" id="tone" name="tone">
                                    <option value="neutral">Neutral</option>
                                    <option value="formal">Formal</option>
                                    <option value="friendly">Friendly</option>
                                    <option value="professional">Professional</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="prompt" class="form-label">What would you like to write about?</label>
                            <textarea class="form-control" id="prompt" name="prompt" rows="3" required placeholder="E.g., 'I need help understanding array functions in PHP' or 'The importance of responsive design in modern websites'"><?php echo isset($_POST['prompt']) ? htmlspecialchars($_POST['prompt']) : ''; ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="length" class="form-label">Length:</label>
                            <select class="form-select" id="length" name="length">
                                <option value="short">Short</option>
                                <option value="medium" selected>Medium</option>
                                <option value="long">Long</option>
                            </select>
                        </div>
                        
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Generate Content</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <?php if (!empty($generated_content)): ?>
            <div class="card mt-4">
                <div class="card-header bg-success text-white">
                    <h2 class="h4 mb-0">Generated Content</h2>
                </div>
                <div class="card-body">
                    <?php if (!empty($generated_title)): ?>
                    <div class="mb-3">
                        <label class="form-label">Title:</label>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($generated_title); ?>" id="generated-title" readonly>
                    </div>
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        <label class="form-label">Content:</label>
                        <textarea class="form-control" rows="10" id="generated-content" readonly><?php echo htmlspecialchars($generated_content); ?></textarea>
                    </div>
                    
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-primary" onclick="copyContent('generated-content')">Copy Content</button>
                        <?php if (!empty($generated_title)): ?>
                        <button type="button" class="btn btn-primary" onclick="copyContent('generated-title')">Copy Title</button>
                        <?php endif; ?>
                        
                        <?php if ($topic_id > 0): ?>
                        <a href="topic.php?id=<?php echo $topic_id; ?>&prefill=true" class="btn btn-success">Use in Reply</a>
                        <?php elseif ($course_id > 0): ?>
                        <a href="create.php?forum_id=<?php echo $course_id; ?>&prefill=true" class="btn btn-success">Create Topic</a>
                        <?php elseif ($category_id > 0): ?>
                        <a href="create.php?category_id=<?php echo $category_id; ?>&prefill=true" class="btn btn-success">Create Topic</a>
                        <?php else: ?>
                        <a href="create.php?prefill=true" class="btn btn-success">Create Topic</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function copyContent(elementId) {
    var element = document.getElementById(elementId);
    element.select();
    document.execCommand('copy');
    
    // Show a temporary success message
    var tooltip = document.createElement('div');
    tooltip.className = 'position-fixed top-50 start-50 translate-middle p-3 bg-success text-white rounded';
    tooltip.innerHTML = 'Copied to clipboard!';
    document.body.appendChild(tooltip);
    
    // Remove the tooltip after 2 seconds
    setTimeout(function() {
        document.body.removeChild(tooltip);
    }, 2000);
}

// Store generated content in session storage for use in other forms
<?php if (!empty($generated_content)): ?>
window.sessionStorage.setItem('generatedContent', <?php echo json_encode($generated_content); ?>);
<?php if (!empty($generated_title)): ?>
window.sessionStorage.setItem('generatedTitle', <?php echo json_encode($generated_title); ?>);
<?php endif; ?>
<?php endif; ?>
</script>

<?php require_once '../includes/footer.php'; ?>