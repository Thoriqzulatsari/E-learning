<?php 
// forum/index.php
require_once '../includes/header.php';
require_once '../includes/db_connection.php';

// Check for stored messages
if (isset($_SESSION['message'])) {
    echo '<div class="container mt-3">';
    echo '<div class="alert alert-' . ($_SESSION['message_type'] === 'error' ? 'danger' : $_SESSION['message_type']) . ' alert-dismissible fade show">';
    echo htmlspecialchars($_SESSION['message']);
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
    echo '</div>';
    echo '</div>';
    
    // Clear the message after displaying
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}

// Get all forum categories
$categories = getForumCategories();

// Get recent topics for display
$stmt = $conn->query("
    SELECT 
        t.topic_id, 
        t.title, 
        t.created_at, 
        t.views, 
        t.user_id,
        t.course_id,
        t.category_id,
        t.last_reply_at,
        u.username AS author_username,
        u.full_name AS author_name,
        c.title AS course_title,
        fc.category_name,
        (SELECT COUNT(*) FROM forum_replies WHERE topic_id = t.topic_id) AS replies_count
    FROM forum_topics t
    JOIN users u ON t.user_id = u.user_id
    LEFT JOIN courses c ON t.course_id = c.course_id
    LEFT JOIN forum_categories fc ON t.category_id = fc.category_id
    ORDER BY COALESCE(t.last_reply_at, t.created_at) DESC
    LIMIT 10
");
$recent_topics = $stmt->fetchAll();
?>

<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Forum</h1>
        <?php if (isset($_SESSION['user_id'])): ?>
        <a href="create.php" class="btn btn-primary">Create New Topic</a>
        <?php else: ?>
        <a href="../login.php" class="btn btn-outline-primary">Log in to post</a>
        <?php endif; ?>
    </div>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h2 class="h5 mb-0">Categories</h2>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php foreach ($categories as $category): ?>
                            <a href="category.php?id=<?php echo $category['category_id']; ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="h6 mb-1"><?php echo htmlspecialchars($category['category_name']); ?></h3>
                                    <p class="mb-0 small text-muted"><?php echo htmlspecialchars($category['category_description']); ?></p>
                                </div>
                                <div class="text-end small">
                                    <div><?php echo $category['topics_count']; ?> Topics</div>
                                    <div><?php echo $category['replies_count']; ?> Replies</div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($recent_topics)): ?>
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h2 class="h5 mb-0">Recent Topics</h2>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php foreach ($recent_topics as $topic): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3 class="h6 mb-1">
                                        <a href="topic.php?id=<?php echo $topic['topic_id']; ?>">
                                            <?php echo htmlspecialchars($topic['title']); ?>
                                        </a>
                                    </h3>
                                    <small class="text-muted"><?php echo formatDateTime($topic['created_at']); ?></small>
                                </div>
                                <div class="d-flex justify-content-between align-items-center small">
                                    <div>
                                        <span class="text-muted">by <?php echo htmlspecialchars($topic['author_name']); ?></span>
                                        <?php if ($topic['category_id']): ?>
                                        <span class="text-muted"> in <a href="category.php?id=<?php echo $topic['category_id']; ?>"><?php echo htmlspecialchars($topic['category_name']); ?></a></span>
                                        <?php elseif ($topic['course_id']): ?>
                                        <span class="text-muted"> in <a href="course_forum.php?id=<?php echo $topic['course_id']; ?>"><?php echo htmlspecialchars($topic['course_title']); ?></a></span>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <span class="badge bg-secondary"><?php echo $topic['replies_count']; ?> <?php echo $topic['replies_count'] == 1 ? 'reply' : 'replies'; ?></span>
                                        <span class="badge bg-light text-dark"><?php echo $topic['views']; ?> views</span>
                                    </div>
                                </div>
                                <?php if ($topic['last_reply_at']): ?>
                                <div class="mt-1 small text-muted">
                                    Latest reply: <?php echo formatDateTime($topic['last_reply_at']); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="alert alert-info">
                No topics have been created yet. Be the first to start a discussion!
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h3 class="h5 mb-0">Forum Statistics</h3>
                </div>
                <div class="card-body">
                    <?php
                    // Get forum statistics
                    $stmt = $conn->query("SELECT COUNT(*) AS topics_count FROM forum_topics");
                    $topics_count = $stmt->fetch()['topics_count'];
                    
                    $stmt = $conn->query("SELECT COUNT(*) AS replies_count FROM forum_replies");
                    $replies_count = $stmt->fetch()['replies_count'];
                    
                    $stmt = $conn->query("SELECT COUNT(DISTINCT user_id) AS users_count FROM (SELECT user_id FROM forum_topics UNION SELECT user_id FROM forum_replies) AS active_users");
                    $users_count = $stmt->fetch()['users_count'];
                    ?>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Total Topics
                            <span class="badge bg-primary rounded-pill"><?php echo $topics_count; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Total Replies
                            <span class="badge bg-primary rounded-pill"><?php echo $replies_count; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Active Members
                            <span class="badge bg-primary rounded-pill"><?php echo $users_count; ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <?php if (isset($_SESSION['user_id'])): ?>
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3 class="h5 mb-0">Your Courses</h3>
                </div>
                <div class="card-body p-0">
                    <?php
                    // Get user's enrolled courses
                    $stmt = $conn->prepare("
                        SELECT c.course_id, c.title 
                        FROM courses c 
                        JOIN enrollments e ON c.course_id = e.course_id 
                        WHERE e.user_id = ?
                        ORDER BY c.title
                    ");
                    $stmt->execute([$_SESSION['user_id']]);
                    $user_courses = $stmt->fetchAll();
                    ?>
                    
                    <?php if (!empty($user_courses)): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($user_courses as $course): ?>
                        <a href="course_forum.php?id=<?php echo $course['course_id']; ?>" class="list-group-item list-group-item-action">
                            <?php echo htmlspecialchars($course['title']); ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <div class="p-3">
                        <p class="mb-0">You are not enrolled in any courses yet.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>