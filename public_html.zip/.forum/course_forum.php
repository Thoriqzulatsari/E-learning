<?php
// forum/course_forum.php
require_once '../includes/header.php';
require_once '../includes/db_connection.php';

// Get course ID from URL
$course_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Check if the course exists
$stmt = $conn->prepare("SELECT * FROM courses WHERE course_id = ?");
$stmt->execute([$course_id]);
$course = $stmt->fetch();

if (!$course) {
    $_SESSION['message'] = "Course not found.";
    $_SESSION['message_type'] = "error";
    header("Location: index.php");
    exit;
}

// Check if user is enrolled in the course or is the instructor
$has_access = false;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Check if user is instructor
    if ($_SESSION['role'] == 'instructor' && $course['instructor_id'] == $user_id) {
        $has_access = true;
    } else {
        // Check if user is enrolled
        $stmt = $conn->prepare("SELECT * FROM enrollments WHERE user_id = ? AND course_id = ?");
        $stmt->execute([$user_id, $course_id]);
        $enrollment = $stmt->fetch();
        
        if ($enrollment) {
            $has_access = true;
        }
    }
}

// If not enrolled and not instructor, redirect
if (!$has_access) {
    $_SESSION['message'] = "You must be enrolled in this course to access its forum.";
    $_SESSION['message_type'] = "error";
    header("Location: index.php");
    exit;
}

// Get topics in this course
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

$topics = getTopicsByCourse($course_id, $per_page, $offset);

// Get total number of topics for pagination
$stmt = $conn->prepare("SELECT COUNT(*) FROM forum_topics WHERE course_id = ?");
$stmt->execute([$course_id]);
$total_topics = $stmt->fetchColumn();
$total_pages = ceil($total_topics / $per_page);

// Check for stored messages
if (isset($_SESSION['message'])) {
    echo '<div class="container mt-3">';
    echo '<div class="alert alert-' . ($_SESSION['message_type'] === 'error' ? 'danger' : $_SESSION['message_type']) . ' alert-dismissible fade show">';
    echo htmlspecialchars($_SESSION['message']);
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
    echo '</div>';
    echo '</div>';
    
    // Clear the message after displaying
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}
?>

<div class="container my-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Forums</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($course['title']); ?> Forum</li>
        </ol>
    </nav>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1><?php echo htmlspecialchars($course['title']); ?> Forum</h1>
            <p class="lead">Discuss topics related to this course with your instructor and classmates.</p>
        </div>
        <a href="create.php?forum_id=<?php echo $course_id; ?>" class="btn btn-primary">Create New Topic</a>
    </div>
    
    <?php if (empty($topics)): ?>
        <div class="alert alert-info">
            No topics have been created in this course forum yet. Be the first to start a discussion!
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-header bg-light">
                <div class="row">
                    <div class="col-md-6">Topic</div>
                    <div class="col-md-2">Author</div>
                    <div class="col-md-1 text-center">Replies</div>
                    <div class="col-md-1 text-center">Views</div>
                    <div class="col-md-2">Last Post</div>
                </div>
            </div>
            <div class="list-group list-group-flush">
                <?php foreach ($topics as $topic): ?>
                    <div class="list-group-item">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h5 class="mb-1">
                                    <?php if ($topic['status'] === 'pinned'): ?>
                                    <span class="badge bg-primary me-1">Pinned</span>
                                    <?php endif; ?>
                                    <a href="topic.php?id=<?php echo $topic['topic_id']; ?>">
                                        <?php echo htmlspecialchars($topic['title']); ?>
                                    </a>
                                </h5>
                                <small class="text-muted">
                                    <?php echo formatDateTime($topic['created_at']); ?>
                                </small>
                            </div>
                            <div class="col-md-2">
                                <?php echo htmlspecialchars($topic['author_name']); ?>
                            </div>
                            <div class="col-md-1 text-center">
                                <?php echo $topic['replies_count']; ?>
                            </div>
                            <div class="col-md-1 text-center">
                                <?php echo $topic['views']; ?>
                            </div>
                            <div class="col-md-2">
                                <?php if ($topic['last_reply_at']): ?>
                                    <small>
                                        <?php echo formatDateTime($topic['last_reply_at']); ?><br>
                                        by <?php echo htmlspecialchars($topic['last_reply_username']); ?>
                                    </small>
                                <?php else: ?>
                                    <small>No replies yet</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation" class="mt-4">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?id=<?php echo $course_id; ?>&page=<?php echo $page - 1; ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                    <a class="page-link" href="?id=<?php echo $course_id; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="?id=<?php echo $course_id; ?>&page=<?php echo $page + 1; ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>